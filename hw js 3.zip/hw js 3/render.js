const form = document.getElementById("postForm");
const postsContainer = document.getElementById("postsContainer");

// Fetch and display all posts
async function fetchPosts() {
  const response = await fetch("/api/posts");
  const posts = await response.json();

  if (posts.length === 0) {
    postsContainer.innerHTML = "You have <b>0</b> posts!";
  } else {
    postsContainer.innerHTML = posts
      .map(
        (post) => `
        <div>
          <h3>${post.title}</h3>
          <small>Created at: ${new Date(post.created_at).toLocaleString()}</small>
          <button onclick="showContent('${post.content.replace(/'/g, "\\'")}')">View</button>
        </div>
      `
      )
      .join("");
  }
}

// Show content in a popup-like window
function showContent(content) {
  const popup = document.createElement("div");
  popup.style.position = "fixed";
  popup.style.top = "20%";
  popup.style.left = "50%";
  popup.style.transform = "translate(-50%, -50%)";
  popup.style.background = "#f9f9f9";
  popup.style.border = "1px solid #ddd";
  popup.style.padding = "1rem";
  popup.style.boxShadow = "0px 0px 10px rgba(0,0,0,0.2)";
  popup.innerHTML = `
    <p>${content}</p>
    <button onclick="this.parentElement.remove()">Close</button>
  `;
  document.body.appendChild(popup);
}

// Submit form to create a new post
form.addEventListener("submit", async (e) => {
  e.preventDefault();
  const title = document.getElementById("title").value;
  const content = document.getElementById("content").value;

  await fetch("/api/posts", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ title, content }),
  });

  form.reset();
  fetchPosts();
});

// Fetch posts on page load
fetchPosts();
