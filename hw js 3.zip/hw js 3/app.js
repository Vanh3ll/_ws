const express = require("express");
const db = require("./db");
const app = express();
const PORT = 3000;

// Middleware to parse JSON and serve static files
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static("public")); // Serve frontend files

// Fetch all posts
app.get("/api/posts", (req, res) => {
  db.all("SELECT * FROM posts ORDER BY created_at DESC", [], (err, rows) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(rows);
  });
});

// Create a new post
app.post("/api/posts", (req, res) => {
  const { title, content } = req.body;
  const createdAt = new Date().toISOString();

  if (!title || !content) {
    return res.status(400).json({ error: "Title and content are required." });
  }

  db.run(
    "INSERT INTO posts (title, content, created_at) VALUES (?, ?, ?)",
    [title, content, createdAt],
    function (err) {
      if (err) return res.status(500).json({ error: err.message });
      res.json({ id: this.lastID, title, content, created_at: createdAt });
    }
  );
});

// Start server
app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
